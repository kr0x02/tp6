<?php /*a:1:{s:55:"E:\phpstudy\phpstudy_pro\WWW\www.study.com\app\404.html";i:1561508951;}*/ ?>
<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0"/>

<title>404页面</title>

<meta name="description" content=""/>

<meta name="keywords" content="" />
<link href="/public/static/index/css/qing.css" rel="stylesheet" type="text/css">


<link href="/favicon.ico">

</head>

<body>
    
    <div class="text_center mar_t_50">
        <a href="/"><img src="/public/static/index/images/404.png"></a>
    </div>

</body>

</html>