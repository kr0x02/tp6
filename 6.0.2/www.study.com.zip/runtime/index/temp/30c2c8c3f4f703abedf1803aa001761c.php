<?php /*a:3:{s:73:"E:\phpstudy\phpstudy_pro\WWW\www.study.com\app\index\view\index\news.html";i:1586160603;s:74:"E:\phpstudy\phpstudy_pro\WWW\www.study.com\app\index\view\public\head.html";i:1586225940;s:74:"E:\phpstudy\phpstudy_pro\WWW\www.study.com\app\index\view\public\foot.html";i:1586161396;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>解决方案_重庆大力电子科技有限公司</title>
<meta name="keywords" content=""/>
<meta name="description" content=""/>

<link href="/public/static/index/css/style.css" rel="stylesheet" type="text/css">
<link href="/public/static/index/css/qing.css" rel="stylesheet" type="text/css">
<link href="/public/static/index/css/qingstyle.css" rel="stylesheet" type="text/css">
<link href="/public/static/index/css/layui.css" rel="stylesheet" type="text/css">
<script src="/public/static/index/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="/public/static/index/js/js.js" type="text/javascript"></script>

</head>
<body>
  <div class="wrap">

    <div class="header_w">
    <div class="header">
      <div class="logo"><a href="/"><img src="/public/static/index/images/logo.png" /></a></div>  
      <div class="h_txt">
        专业拨动开关轻触开关USB插座生产厂家
      </div>
      <div class="h_tel"><span class="tel_tit">全国服务热线</span><span class="tel_num"><?php echo htmlentities($tel1); ?></span></div>
      <div class="btn_menu"></div>
      <div class="clear"></div>
    </div>
</div>

<!--手机版 导航菜单遮罩层 start-->
<div class="mask"></div>
  <div class="nav_w">
  <div class="close"></div>
  <div class="nav">
    <ul>
      <li  <?php if($menu_id == 0): ?>class='current'<?php endif; ?>>
        <a href="/">网站首页</a>
      </li>
      <li <?php if($menu_id == 1): ?>class='current'<?php endif; ?>>
        <a href="<?php echo url('index/index/company'); ?>">企业简介</a>
        
      </li>
      <li>
        <a href="<?php echo url('index/index/product'); ?>">产品中心</a>
        
      </li>
      <li>
        <a href="<?php echo url('index/index/news'); ?>">解决方案</a>
        
      </li>
      <li>
        <a href="<?php echo url('index/index/news'); ?>">资讯动态</a>
        
      </li>
       <li <?php if($menu_id == 7): ?>class='current'<?php endif; ?>>
        <a href="<?php echo url('index/index/contact'); ?>">联系我们</a>
      </li> 
      </ul>
      <div class="clear"></div>
  </div>
  </div> 


  <div class="solutionbg" style="background: url(static/images/solution_bg.jpg) no-repeat center center; width: 100%;height: 348px"></div>
  <div class="positionbg">
    
      <div class="layui-container">  

        <img src="static/images/home.jpg">&nbsp;当前位置：<a href='/'>首页</a> > <a href='/jjfa/'>解决方案</a> > 

      </div>

  </div>

  <div class="layui-container"> 


    <div class="mar_t_30 mar_b_30" id="nleft_content">
  
      <div class="nleft_title fb f16 color1">产品中心</div>
      <div class="nleft_boder">
        
          <ul class="chanpin_logo">

            <li><a href="/cpzx/HUAWEI/"><img src="static/images/hz_1.jpg"></a></li>
            <li><a href="/cpzx/F5/"><img src="static/images/hz_2.jpg"></a></li>
            <li><a href="/cpzx/H3C/"><img src="static/images/hz_3.jpg"></a></li>
            <li><a href="/cpzx/JUNIPER/"><img src="static/images/hz_4.jpg"></a></li>

          </ul>

      </div>
      <div class="nleft_title fb f16 mar_t_20 color1">联系我们</div>
      <div class="nleft_boder line30">
          <div style="padding:20px 30px">
            <div class="fb">重庆大力科技电子有限公司</div> 
            全国咨询热线：86978888
            <img src="static/images/contactimg.jpg">
          </div>

      </div>


  </div>

          <div class="mar_t_30 mar_b_30" id="nright_content">

              <ul class="nsolution">

                  <li>

                      <div class="title"><a href="/jjfa/70.html">产品维修服务</a></div>
                      <div class="time"> 2020-02-28</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/1.html">链路负载均衡解决方案</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/2.html">本地流量管理器</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/3.html">链路控制器</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/4.html">多链路负载均衡解决方案</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/5.html">服务器负载解决方案</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/6.html">本地服务器负载均衡和优化处理</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/7.html">教育解决方案</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/8.html">企业解决方案</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li><li>

                      <div class="title"><a href="/jjfa/9.html">上网行为管理主要功能</a></div>
                      <div class="time"> 2020-02-27</div>
                      

                  </li>


              </ul>

              <div class="fenye"> <li><span class="pageinfo">共 <strong>1</strong> 页 <strong>10</strong> 条记录</span></li>
</div>


          </div>



  </div>

  <div class="footer_w">
    <div class="footer">
      <div class="txt">
         <div class="t_1"><?php echo htmlentities($web_title); ?></div>
      
         <div class="t_2">全国统一咨询热线：<?php echo htmlentities($tel1); ?> &nbsp;<br>
  <span>联系地址：<?php echo htmlentities($address); ?> &nbsp;<?php echo htmlentities($beian); ?></span>
          </div>
      </div>
      <div class="ewm">
        <div class="pic"><img src="/public/static/index/images/ewm.jpg" width="87" height="87"></div>
        <div class="ewm_txt">
        微信扫一扫<br>
  即时与客服沟通
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  
</div>

</body>
</html>